package com.kodilla;

public class FirstClass {
}
