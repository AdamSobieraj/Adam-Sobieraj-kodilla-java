package com.kodilla.stream.lambda;

public interface Executor {
    public void process();
}
