package com.kodilla.stream.lambda;

public class Processor {
    public void execute(Executor executor) {
        executor.process();
    }
}
