package com.kodilla.stream.lambda;

public interface MathExpression {
    public double calculateExpression(double a, double b);
}
