package com.kodilla.stream.beautifier;

public interface PoemDecorator {
    public String decorate(String s);
}
