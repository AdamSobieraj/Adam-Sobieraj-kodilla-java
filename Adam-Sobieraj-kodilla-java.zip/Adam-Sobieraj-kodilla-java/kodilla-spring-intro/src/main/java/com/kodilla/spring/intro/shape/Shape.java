package com.kodilla.spring.intro.shape;

public interface Shape {
    String draw();
}

