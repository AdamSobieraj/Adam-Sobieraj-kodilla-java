package com.kodilla.spring.intro.shape;

public class Figure {
    public void draw() {
        System.out.println("This is a geometric figure");
    }
}
