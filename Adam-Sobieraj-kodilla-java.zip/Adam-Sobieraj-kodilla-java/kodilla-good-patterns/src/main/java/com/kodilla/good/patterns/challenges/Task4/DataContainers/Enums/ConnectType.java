package com.kodilla.good.patterns.challenges.Task4.DataContainers.Enums;

public enum ConnectType {

    DIRECT_FROM,
    DIRECT_TO,
    DIRECT_FROM_TO,
    DIRECT_OR_INDIRECT_FROM_TO,
    INDIRECT_FROM_TO_THREW;

}
