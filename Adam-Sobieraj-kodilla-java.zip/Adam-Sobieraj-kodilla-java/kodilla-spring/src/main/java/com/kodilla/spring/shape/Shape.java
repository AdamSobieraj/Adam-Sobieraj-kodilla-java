package com.kodilla.spring.shape;

public interface Shape {
    String getShapeName();
}
