package com.kodilla.rps;

public enum PCGameChoose {
    PC_GAME_CHOOSE_KAMIEN,
    PC_GAME_CHOOSE_PAPIER,
    PC_GAME_CHOOSE_NOZYCE
}
