package com.kodilla.rps.xx;

public class AppRPS {

    public static void main(String[] args) {
        //pobieramy nazwe gracza ilość rund , tworzymy obiekty human Computer, game, game controller
    }
}
