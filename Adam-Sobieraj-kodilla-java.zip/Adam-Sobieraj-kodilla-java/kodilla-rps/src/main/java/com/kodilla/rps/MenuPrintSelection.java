package com.kodilla.rps;

public enum MenuPrintSelection {
    ENTER_NAME,
    ENTER_SURNAME,
    PERSON_EXIST,
    PROGRAM_EXIT_MESSAGE,
    MAIN_MENU_SELECTION_DEFAULT,
    MAIN_MENU_PRINT,
    NO_USER_SELECTED,
    TO_HOW_MANY_WINS_QUESTION



}
