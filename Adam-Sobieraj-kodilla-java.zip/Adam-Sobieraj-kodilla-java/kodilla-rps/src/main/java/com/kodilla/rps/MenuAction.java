package com.kodilla.rps;

public enum MenuAction {
    ADD_PERSON,
    START_GAME,
    FIND_PERSON,
    DISPLAY_ALL_PLAYERS,
    SAVE_BOOK_LIST,
    EXIT
}
