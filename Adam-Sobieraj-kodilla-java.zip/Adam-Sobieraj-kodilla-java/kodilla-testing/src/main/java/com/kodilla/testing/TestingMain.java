package com.kodilla.testing;
import com.kodilla.testing.calculator.Calculator;
import com.kodilla.testing.user.SimpleUser;

public class TestingMain {
    public static void main(String[] args) {
        /*
        SimpleUser simpleUser = new SimpleUser("theForumUser");
        String result = simpleUser.getUsername();

        if (result.equals("theForumUser")){
            System.out.println("test OK");
        } else {
            System.out.println("Error!");
        }


        Calculator theNewCal = new Calculator();
        Integer expected = 7;
        Integer actual = theNewCal.add(3,4);
        if (actual.equals(expected)){
            System.out.println("test OK of add");
        }else {
            System.out.println("Add Error!");
        }

        Integer expcetedSubstract = 6;
        Integer actualSubstract = theNewCal.substract(8,2);
        if (actualSubstract.equals(expcetedSubstract)){
            System.out.println("test OK of Substract");
        }else {
            System.out.println("Substract Error!");
        }
        //Tested resoult with try cath
        //Test for devide by 0
        try{
            theNewCal.substract(4,0);
            System.out.println("exception");
        }catch (ArithmeticException e){
            System.out.println("Test output" + e.getLocalizedMessage());
        }


*/
    }

}

