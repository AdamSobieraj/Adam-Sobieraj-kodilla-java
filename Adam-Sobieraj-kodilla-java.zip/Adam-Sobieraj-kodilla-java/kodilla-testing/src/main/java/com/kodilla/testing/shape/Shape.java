package com.kodilla.testing.shape;

public interface Shape {
     void getShapeName();
     double getField();
}
